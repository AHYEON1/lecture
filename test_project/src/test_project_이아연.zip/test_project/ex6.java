package test_project;

public class ex6 {
 public static void main(String[] args) {
 int sum =0; 
 int num = -1; 
 while(true) {
	 if(num%2 != 0) {
		 sum += sum;
	
	 }else {
		 sum += num*-1;
	
	 }
	 if(sum >=100) {
		 System.out.println(num);
		 break;
	 }
	 num++;
 }
	
	  }
	  
 }


 
	 
