package test_project;

public class ex5 {
	public static void main(String[] args) {  
//		�ֻ��� ���� 
        
		int i ;
		int j;
	
		
		for( i =1; i<6; i++) {
			for(j=1; j<6; j++) {
				if(i+j ==6)
				System.out.println(i+""+j);
			}
		}
}
}
